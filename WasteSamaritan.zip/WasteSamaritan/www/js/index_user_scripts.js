/*jshint browser:true */
/*global $ */(function()
{
 "use strict";
var firebase = new Firebase("https://wastesamaritan.firebaseio.com/");
var pictureSource;   // picture source
var destinationType; // sets the format of returned value
var imgdata; 
var myLatLng;
var firebaselocation = new Firebase("https://wastetracker.firebaseio.com/");
var options = {
    timeout: 10000,
    maximumAge: 11000,
    enableHighAccuracy: true
};

 /*
   hook up event handlers 
 */
 function register_event_handlers()
 {
    //var macAddress="98:D3:31:50:0C:9C";// for red scale
    var macAddress="98:D3:33:80:7E:27";// for black scale
     bluetoothSerial.connect(macAddress, 
            function(){console.log("bluetooth connection success"); bluetoothSerial.subscribe('\n',function(data){weightUpdate(data)}   )}, function (err) {
                       alert("turn on bluetooth")
                console.log(err);
            });   
     
       var suc = function(p) {
       
        
            //myLatLng = new google.maps.LatLng(p.coords.latitude, p.coords.longitude);
         firebaselocation.set({currentlocation:{lat:p.coords.latitude, lng:p.coords.longitude}});
       
    };   
	

var fail = function() {
        console.log("Geolocation failed. \nPlease enable GPS in Settings.", 1);
    };
     
     //navigation tracker of collector
      if (navigator.geolocation !== null) {
            
            navigator.geolocation.watchPosition(suc, fail, options);
        }
        else {
            alert("navigator.geolocation == null")
        }
     
   
                              
     
        pictureSource=navigator.camera.PictureSourceType;
        destinationType=navigator.camera.DestinationType;
    
    function weightUpdate(weight){
        console.log(weight)
    $('#weight').val(weight);        
            
    }
     /* button  LOGIN */
     function onPhotoDataSuccess(imageData) {
      // Uncomment to view the base64-encoded image data
      //console.log(imageData);

      imgdata= imageData;
         // firebase.push({"house 5":{image:{format:"data:image/jpeg;base64,",imgaeData:imgdata}}}); 
    }
     function onFail(message) {
      alert('Failed because: ' + message);
    }
    
        /* button  LOGIN */
    $(document).on("click", ".uib_w_5", function(evt)
    {
         /*global activate_page */
         activate_page("#page1"); 
    });
    
        /* graphic button  Button */
    $(document).on("click", ".uib_w_6", function(evt)
    {
        /* your code goes here */ 
    });
    
        /* button  #qrscan */
    
    
        /* button */
    $(document).on("click", "undefined", function(evt)
    {
         /*global activate_page */
         activate_page("#page1"); 
    });
    
        /* button */
    $(document).on("click", "undefined", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#page_97_21"); 
    });
    
        /* button */
    $(document).on("click", "undefined", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#page_97_21"); 
    });
    
        /* button  #qrscan */
    
    
        /* button  #home */
    $(document).on("click", "#home", function(evt)
    {
         /*global activate_page */
         activate_page("#page1"); 
    });
    
     function addZero(i) {
            if (i < 10) {
                i = "0" + i;
            }
            return i;
        }
                /* button  #upload */
     $(document).on("click", "#upload", function(evt)
    {
         /*global activate_page */
         var address=$("#address").val();
         var weight=$('#weight').val();
         var rating=4;
         var wastetype="dry";
        
         if($("#star5")[0].checked==true)
             {
                 rating=5;
             }
         else if($("#star4")[0].checked)
             {
                 rating=4;
             }
         else if($("#star3")[0].checked)
             {
                 rating=3;
             }
         else if($("#star2")[0].checked)
             {
                 rating=2;
             }
         else if($("#star1")[0].checked)
             {
                 rating=1;
             }
         
         console.log(rating)
         if(rating<4)
         {
         navigator.camera.getPicture(onPhotoDataSuccess, onFail, { quality: 20,
         destinationType: destinationType.DATA_URL });
         }
            var d = new Date();    
            var h = addZero(d.getHours());
            var m = addZero(d.getMinutes());
            var s = addZero(d.getSeconds());
            var timestamp =d.toDateString()+", "+ h + ":" + m + ":" + s ;             
         console.log(timestamp);
     /*  firebase.push({"house 4":{ address:"House No. 4, Domlur, Ward No. :112, 45-Day Challenge Pilot by Krishna	", Rating :5,Quantity :"4.564 kgs" }});
         firebase.push({"house 3":{ address:"House No. 3, Domlur, Ward No. :112, 45-Day Challenge Pilot by Krishna	", Rating :4, Quantity :"3.700 kgs" }});
          firebase.push({"house 2":{ address:"House No. 2, Domlur, Ward No. :112, 45-Day Challenge Pilot by Krishna	", Rating :4, Quantity :"5.618 kgs" }});
          firebase.push({"house 1":{ address:"House No. 1, Domlur, Ward No. :112, 45-Day Challenge Pilot by Krishna	", Rating :5, Quantity :"7.012 kgs" }}) ;*/
         if($("#wetwaste")[0].checked)
             {
                 wastetype="wet";
             }
         
         
         firebase.push({"house 5":{"Quantity(Kgs)" :weight,Rating :rating,Timestamp:timestamp,Address:address,"Waste Category":wastetype }});    
         console.log("data pushed successfully")
              activate_page("#page1");
         
         
    });
    
        /* button  #qrscan */
    $(document).on("click", "#qrscan", function(evt)
    {    cordova.plugins.barcodeScanner.scan(
                function (result) {
                    console.log( "Scanned result found!");
                    console.log("We got a barcode!\n" +
                        "Result: " + result.text + "\n" +
                        "Format: " + result.format + "\n" +
                        "Cancelled: " + result.cancelled + "\n\n" 
                       );
                    activate_page("#page");
                    $("#address").val(result.text);
                },
                function (error) {
                    alert("Scanning failed: " + error);
                }
            );
         /*global activate_page */
          
    });
    
        /* button  #logs */
    $(document).on("click", "#logs", function(evt)
    {     var d=new Date();
            activate_page("#page2"); 
     $("#date").val(d.toDateString()); 
     
         /*global activate_page */
         
    });
    
        /* button  #home1 */
    $(document).on("click", "#home1", function(evt)
    {
         /*global activate_page */
         activate_page("#page1"); 
    });
    
    }
 document.addEventListener("app.Ready", register_event_handlers, false);
})();
